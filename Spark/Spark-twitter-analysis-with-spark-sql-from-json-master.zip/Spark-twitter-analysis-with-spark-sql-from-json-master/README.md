# Spark-twitter-analysis-with-spark-sql-from-json
How to do simple analysis on tweets with twitter api with spark SQL From Json file

Youtube tutorial : https://www.youtube.com/watch?v=CNu2O8dc70M

Blog Tutorial : http://blog-wassim.azurewebsites.net/en/spark-for-beginners-tutorials-spark-twitter-analysis-with-spark-sql-example/
